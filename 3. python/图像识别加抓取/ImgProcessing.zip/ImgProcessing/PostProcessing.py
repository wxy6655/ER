# Post Processing is used to verify the result of imgProcessing


class PostProcessing(object):

    def __init__(self):
        pass

    def postProcess(self,frame):
        return frame

