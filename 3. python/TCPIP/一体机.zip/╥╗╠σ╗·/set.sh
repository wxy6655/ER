#!/bin/bash
sudo cp add_img.py ~/catkin_ws/src/mycobot_ros/mycobot_ai/scripts
sudo cp ai_windows.py ~/Desktop
sudo cp mycobot_topics.py ~/catkin_ws/src/mycobot_ros/mycobot_communication/scripts
sudo cp vision.launch ~/catkin_ws/src/mycobot_ros/mycobot_ai/launch

sudo sed -i '109,116d' ~/catkin_ws/src/mycobot_ros/mycobot_ai/scripts/detect_obj_color.py
sudo sed -i '/GPIO/d' ~/catkin_ws/src/mycobot_ros/mycobot_ai/scripts/detect_obj_color.py

sudo sed -i 's/self.gpio_status(True)/self.pub_pump(True,[20,21])/g' ~/catkin_ws/src/mycobot_ros/mycobot_ai/scripts/detect_obj_color.py
sudo sed -i 's/self.gpio_status(False)/self.pub_pump(False,[20,21])/g' ~/catkin_ws/src/mycobot_ros/mycobot_ai/scripts/detect_obj_color.py