#!/bin/bash
sudo systemctl stop mycobot_socket.service
ps -ef | grep -E "Server.py" | grep -v "grep" | awk '{print $2}' | xargs kill -9
