#!/bin/bash

sudo cp Server.py ~
sudo cp mycobot_socket.service /etc/systemd/system/
sudo cp open_socket.sh ~/Desktop
sudo cp close_socket.sh ~/Desktop
sudo chmod +x ~/Desktop/open_socket.sh
sudo chmod +x ~/Desktop/close_socket.sh
sudo systemctl enable mycobot_socket.service
sudo sed -i '/create_ap/d' /etc/rc.local
if cat /etc/rc.local | grep "netplan" > /dev/null
then
	echo 0
else
	sudo sed -i '/hwclock -s/a\sudo netplan apply' /etc/rc.local
fi
sudo mv /etc/netplan/50-cloud-init.yaml /etc/netplan/50-cloud-init.yaml.bak
sudo cp 50-cloud-init.yaml /etc/netplan/
sudo netplan apply
sudo systemctl disable systemd-networkd-wait-online.service
sudo systemctl start mycobot_socket.service
