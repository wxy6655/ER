#!/bin/bash
sudo systemctl enable mycobot_socket.service
sudo systemctl start mycobot_socket.service